﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace book
{
    public partial class Form2 : Form
    {
        private string[] lis1;
        string[] result;
        string money;
        int money1;
        int count = 0;
       
        public Form2(string[] finaly)
        {
            InitializeComponent();
            lis1 = finaly;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            label5.Text = "";
            label6.Text = "";
            textBox1.Focus();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ممنون از خرید شما");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string buy = textBox1.Text;
            string buy1 = textBox2.Text;
            foreach (string i in lis1)
            {
                if (i.Contains(buy) && i.Contains(buy1))
                {
                    result = i.Split(",");
                    money = result[3];
                    string m = (result[count] + " :کتاب موجود است. نام کتاب");
                    string s = (result[2] + " :نام نویسنده");
                    label5.Text = m;
                    label6.Text = s;
                    break;


                }
                else
                {
                    MessageBox.Show("کتاب موجود نیست");
                    break;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text))
            {
                MessageBox.Show("enter the count");
            }
            else
            {
                int texbox_3 = Int32.Parse(textBox3.Text);
                money1 = Int32.Parse(money) * texbox_3;
                string a = money1.ToString();
                textBox4.Text = a;
            }
        }

        
    }
}
