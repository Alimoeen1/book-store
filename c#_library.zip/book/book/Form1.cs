﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace book
{
    public partial class Form1 : Form
    {
        public static string[] lis1 = new string[10];
        public static string[] lis2 = new string[10];
        string result1;
        string Add;
        public Form1()
        {
            InitializeComponent();
        }
        

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog add = new OpenFileDialog();
            add.Filter = "(*.jpg; *.png; *.gif)|*.jpg; *.png; *.gif";
            add.ShowDialog();
            pictureBox2.Image = Image.FromFile(add.FileName);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string name_book = textBox1.Text;
            string mozo_book = comboBox1.Text;
            string name_writer = textBox2.Text;
            string price_book = textBox3.Text;

            // i It has the role of a counter
            int i = 0;
            result1 = name_book + "," + mozo_book + "," + name_writer + "," + price_book;
            lis1[i] = result1;
            i += 1;
           
            ListViewItem newitem = new ListViewItem(textBox1.Text);
            newitem.SubItems.Add(textBox2.Text);
            newitem.SubItems.Add(textBox3.Text);
            newitem.SubItems.Add(comboBox1.Text);
            listView1.Items.Add(newitem);
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            comboBox1.Text = "";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(lis1);
            form2.Show();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Add = textBox5.Text;
            comboBox1.Items.Add(Add);
            textBox5.Text = "";
            textBox5.Focus();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            TreeNode node = new TreeNode(textBox6.Text);
            treeView1.Nodes.Add(node);
            textBox6.Text = "";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            TreeNode node = new TreeNode(comboBox2.SelectedItem.ToString());
            treeView1.SelectedNode.Nodes.Add(node);
            comboBox2.Text = "";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string res;
            res = textBox7.Text;
            comboBox2.Items.Add(res);
            textBox7.Text = "";
            textBox7.Focus();
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            pictureBox2.Height += 15;
            pictureBox2.Width += 15;
       
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Height -= 15;
            pictureBox2.Width -= 15;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.Columns.Add("namebook", 100);
            listView1.Columns.Add("namewriter", 120);
            listView1.Columns.Add("price", 80);
            listView1.Columns.Add("Issue", 100);
        }

        private void مونثToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(fontDialog1.ShowDialog() == DialogResult.OK)
            {
                this.Font = fontDialog1.Font;

            }
        }

        private void عوضکردنرنگToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(colorDialog1.ShowDialog()  == DialogResult.OK)
            {
                Color color = colorDialog1.Color;
                BackColor = color;
            }
            
        }

        private void خروجToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void مشاهدهموجودیToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void ثبتکتابToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
            textBox1.Focus();
        }

        private void سفارشخریدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(lis1);
            form2.Show();

        }
    }                   
}
